import mysql from "mysql2/promise"

// Database configuration
const dbConfig = {
  host: process.env.DB_HOST || "localhost",
  port: Number.parseInt(process.env.DB_PORT || "3306"),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "streetsource",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
}

// Create connection pool
const pool = mysql.createPool(dbConfig)

// Database utility functions
export class Database {
  // Test connection
  static async testConnection() {
    try {
      const connection = await pool.getConnection()
      await connection.ping()
      connection.release()
      console.log("✅ Database connected successfully")
      return true
    } catch (error) {
      console.error("❌ Database connection failed:", error)
      return false
    }
  }

  // Execute query
  static async query(sql: string, params: any[] = []) {
    try {
      const [results] = await pool.execute(sql, params)
      return results
    } catch (error) {
      console.error("Database query error:", error)
      throw error
    }
  }

  // Get user by email
  static async getUserByEmail(email: string) {
    const sql = "SELECT * FROM users WHERE email = ? AND is_active = TRUE"
    const results = (await this.query(sql, [email])) as any[]
    return results[0] || null
  }

  // Create user
  static async createUser(userData: any) {
    const sql = `
      INSERT INTO users (
        name, email, password_hash, role, phone, address,
        shop_name, shop_type, business_name, business_type, specialization,
        vehicle_type, license_number, availability, emergency_contact, emergency_phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `
    const params = [
      userData.name,
      userData.email,
      userData.password_hash,
      userData.role,
      userData.phone,
      userData.address,
      userData.shop_name || null,
      userData.shop_type || null,
      userData.business_name || null,
      userData.business_type || null,
      userData.specialization || null,
      userData.vehicle_type || null,
      userData.license_number || null,
      userData.availability || null,
      userData.emergency_contact || null,
      userData.emergency_phone || null,
    ]

    const result = (await this.query(sql, params)) as any
    return result.insertId
  }

  // Get products with supplier info
  static async getProducts(filters: any = {}) {
    let sql = `
      SELECT 
        p.*,
        u.name as supplier_name,
        u.address as supplier_location,
        u.phone as supplier_phone,
        u.rating as supplier_rating
      FROM products p
      JOIN users u ON p.supplier_id = u.id
      WHERE p.is_available = TRUE
    `
    const params: any[] = []

    if (filters.category) {
      sql += " AND p.category = ?"
      params.push(filters.category)
    }

    if (filters.maxPrice) {
      sql += " AND p.price <= ?"
      params.push(filters.maxPrice)
    }

    if (filters.search) {
      sql += " AND p.name LIKE ?"
      params.push(`%${filters.search}%`)
    }

    sql += " ORDER BY p.created_at DESC"

    return await this.query(sql, params)
  }

  // Get orders for user
  static async getOrdersForUser(userId: string, role: string) {
    let sql = `
      SELECT 
        o.*,
        GROUP_CONCAT(
          JSON_OBJECT(
            'product_id', oi.product_id,
            'product_name', p.name,
            'quantity', oi.quantity,
            'unit_price', oi.unit_price,
            'total_price', oi.total_price
          )
        ) as items
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      LEFT JOIN products p ON oi.product_id = p.id
    `

    if (role === "vendor") {
      sql += " WHERE o.vendor_id = ?"
    } else if (role === "volunteer") {
      sql += " WHERE o.volunteer_id = ?"
    } else if (role === "supplier") {
      sql += ` 
        WHERE o.id IN (
          SELECT DISTINCT oi2.order_id 
          FROM order_items oi2 
          JOIN products p2 ON oi2.product_id = p2.id 
          WHERE p2.supplier_id = ?
        )
      `
    }

    sql += " GROUP BY o.id ORDER BY o.created_at DESC"

    const results = (await this.query(sql, [userId])) as any[]

    // Parse the JSON items
    return results.map((order) => ({
      ...order,
      items: order.items ? JSON.parse(`[${order.items}]`) : [],
    }))
  }

  // Create order
  static async createOrder(orderData: any) {
    const connection = await pool.getConnection()

    try {
      await connection.beginTransaction()

      // Insert order
      const orderSql = `
        INSERT INTO orders (
          vendor_id, total_amount, shop_name, shop_address, 
          shop_landmark, shop_lat, shop_lng, estimated_delivery
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `
      const [orderResult] = (await connection.execute(orderSql, [
        orderData.vendor_id,
        orderData.total_amount,
        orderData.shop_name,
        orderData.shop_address,
        orderData.shop_landmark,
        orderData.shop_lat,
        orderData.shop_lng,
        orderData.estimated_delivery,
      ])) as any

      const orderId = orderResult.insertId

      // Insert order items
      for (const item of orderData.items) {
        const itemSql = `
          INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price)
          VALUES (?, ?, ?, ?, ?)
        `
        await connection.execute(itemSql, [orderId, item.product_id, item.quantity, item.unit_price, item.total_price])
      }

      await connection.commit()
      return orderId
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  }

  // Update order status
  static async updateOrderStatus(orderId: string, status: string, volunteerId?: string) {
    let sql = "UPDATE orders SET status = ?"
    const params = [status]

    if (volunteerId) {
      sql += ", volunteer_id = ?"
      params.push(volunteerId)
    }

    if (status === "delivered") {
      sql += ", actual_delivery = NOW()"
    }

    sql += " WHERE id = ?"
    params.push(orderId)

    return await this.query(sql, params)
  }

  // Get earnings for volunteer
  static async getVolunteerEarnings(volunteerId: string) {
    const sql = `
      SELECT 
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN total_earning ELSE 0 END) as today_earnings,
        SUM(CASE WHEN YEARWEEK(created_at) = YEARWEEK(NOW()) THEN total_earning ELSE 0 END) as week_earnings,
        SUM(CASE WHEN MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW()) THEN total_earning ELSE 0 END) as month_earnings,
        SUM(total_earning) as total_earnings,
        COUNT(*) as total_deliveries
      FROM earnings 
      WHERE volunteer_id = ?
    `
    const results = (await this.query(sql, [volunteerId])) as any[]
    return (
      results[0] || {
        today_earnings: 0,
        week_earnings: 0,
        month_earnings: 0,
        total_earnings: 0,
        total_deliveries: 0,
      }
    )
  }
}

export default Database
