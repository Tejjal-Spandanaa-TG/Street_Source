"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  name: string
  email: string
  role: "vendor" | "supplier" | "volunteer"
  phone: string
  address: string
  shop_name?: string
  shop_type?: string
  business_name?: string
  business_type?: string
  specialization?: string
  vehicle_type?: string
  rating?: number
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (userData: any) => Promise<boolean>
  logout: () => void
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check for stored user session only once on mount
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch (error) {
        localStorage.removeItem("user")
      }
    }
    setLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // For demo purposes, we'll still use the mock authentication
      // In production, you would verify against the database
      const mockUsers = [
        {
          id: "vendor-1",
          name: "Raj Kumar",
          email: "vendor@demo.com",
          role: "vendor" as const,
          phone: "+91 9876543210",
          address: "Connaught Place, New Delhi",
          shop_name: "Raj's Chaat Corner",
          shop_type: "Chaat, Snacks",
        },
        {
          id: "supplier-1",
          name: "Ramesh Vegetables",
          email: "supplier@demo.com",
          role: "supplier" as const,
          phone: "+91 9876543212",
          address: "Azadpur Mandi, Delhi",
          business_name: "Ramesh Fresh Vegetables",
          specialization: "vegetables",
        },
        {
          id: "volunteer-1",
          name: "Amit Singh",
          email: "volunteer@demo.com",
          role: "volunteer" as const,
          phone: "+91 9876543215",
          address: "Karol Bagh, New Delhi",
          vehicle_type: "motorcycle",
          rating: 4.8,
        },
      ]

      const foundUser = mockUsers.find((u) => u.email === email)
      if (foundUser && password === "demo123") {
        setUser(foundUser)
        localStorage.setItem("user", JSON.stringify(foundUser))
        return true
      }

      // Uncomment this for real database authentication:
      /*
      const dbUser = await Database.getUserByEmail(email)
      if (dbUser && await bcrypt.compare(password, dbUser.password_hash)) {
        const userData = {
          id: dbUser.id,
          name: dbUser.name,
          email: dbUser.email,
          role: dbUser.role,
          phone: dbUser.phone,
          address: dbUser.address,
          shop_name: dbUser.shop_name,
          shop_type: dbUser.shop_type,
          business_name: dbUser.business_name,
          business_type: dbUser.business_type,
          specialization: dbUser.specialization,
          vehicle_type: dbUser.vehicle_type,
          rating: dbUser.rating
        }
        setUser(userData)
        localStorage.setItem("user", JSON.stringify(userData))
        return true
      }
      */

      return false
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const register = async (userData: any): Promise<boolean> => {
    try {
      // For demo purposes, we'll create a mock user
      const newUser: User = {
        id: Date.now().toString(),
        name: userData.name,
        email: userData.email,
        role: userData.role,
        phone: userData.phone,
        address: userData.address,
        shop_name: userData.shopName,
        shop_type: userData.shopType,
        business_name: userData.businessName,
        business_type: userData.businessType,
        specialization: userData.specialization,
        vehicle_type: userData.vehicleType,
      }

      setUser(newUser)
      localStorage.setItem("user", JSON.stringify(newUser))

      // Uncomment this for real database registration:
      /*
      const hashedPassword = await bcrypt.hash(userData.password, 10)
      const dbUserData = {
        ...userData,
        password_hash: hashedPassword
      }
      
      const userId = await Database.createUser(dbUserData)
      const newUser: User = {
        id: userId,
        name: userData.name,
        email: userData.email,
        role: userData.role,
        phone: userData.phone,
        address: userData.address,
        shop_name: userData.shop_name,
        shop_type: userData.shop_type,
        business_name: userData.business_name,
        business_type: userData.business_type,
        specialization: userData.specialization,
        vehicle_type: userData.vehicle_type,
      }

      setUser(newUser)
      localStorage.setItem("user", JSON.stringify(newUser))
      */

      return true
    } catch (error) {
      console.error("Registration error:", error)
      return false
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
    window.location.href = "/"
  }

  return <AuthContext.Provider value={{ user, login, register, logout, loading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
