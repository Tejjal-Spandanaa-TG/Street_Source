"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

interface OrderItem {
  productId: string
  productName: string
  quantity: number
  price: number
  supplierId: string
}

interface ShopDetails {
  name: string
  address: string
  landmark: string
  coordinates: {
    lat: number
    lng: number
  }
}

interface Order {
  id: string
  vendorId: string
  volunteerId?: string
  items: OrderItem[]
  status: "pending" | "accepted" | "rejected" | "in_transit" | "delivered"
  total: number
  createdAt: Date
  estimatedDelivery: Date
  shopDetails?: ShopDetails
}

interface OrdersContextType {
  orders: Order[]
  addOrder: (order: Order) => void
  updateOrderStatus: (orderId: string, status: Order["status"]) => void
}

const OrdersContext = createContext<OrdersContextType | undefined>(undefined)

export function OrdersProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([
    {
      id: "1001",
      vendorId: "1",
      items: [
        { productId: "1", productName: "Fresh Onions", quantity: 5, price: 15, supplierId: "2" },
        { productId: "2", productName: "Tomatoes", quantity: 3, price: 25, supplierId: "2" },
      ],
      status: "delivered",
      total: 150,
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
      estimatedDelivery: new Date(Date.now() - 22 * 60 * 60 * 1000),
      shopDetails: {
        name: "Raj's Chaat Corner",
        address: "Shop 15, Connaught Place, New Delhi - 110001",
        landmark: "Near Central Park Metro Station",
        coordinates: { lat: 28.6315, lng: 77.2167 },
      },
    },
    {
      id: "1002",
      vendorId: "1",
      volunteerId: "3",
      items: [{ productId: "3", productName: "Garam Masala", quantity: 1, price: 120, supplierId: "2" }],
      status: "in_transit",
      total: 120,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      estimatedDelivery: new Date(Date.now() + 1 * 60 * 60 * 1000),
      shopDetails: {
        name: "Delhi Street Food Hub",
        address: "Block A, Karol Bagh Market, New Delhi - 110005",
        landmark: "Opposite Karol Bagh Metro Station",
        coordinates: { lat: 28.6519, lng: 77.1909 },
      },
    },
  ])

  const addOrder = (order: Order) => {
    setOrders((prev) => [...prev, order])
  }

  const updateOrderStatus = (orderId: string, status: Order["status"]) => {
    setOrders((prev) => prev.map((order) => (order.id === orderId ? { ...order, status } : order)))
  }

  return <OrdersContext.Provider value={{ orders, addOrder, updateOrderStatus }}>{children}</OrdersContext.Provider>
}

export function useOrders() {
  const context = useContext(OrdersContext)
  if (context === undefined) {
    throw new Error("useOrders must be used within an OrdersProvider")
  }
  return context
}
