"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"

interface Toast {
  id: string
  message: string
  type: "success" | "error" | "info"
}

interface ToastContextType {
  toasts: Toast[]
  addToast: (message: string, type: Toast["type"]) => void
  removeToast: (id: string) => void
}

const ToastContext = createContext<ToastContextType | undefined>(undefined)

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  const addToast = useCallback((message: string, type: Toast["type"]) => {
    const id = Date.now().toString()
    const toast: Toast = { id, message, type }

    setToasts((prev) => [...prev, toast])

    // Auto remove after 3 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id))
    }, 3000)
  }, [])

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id))
  }, [])

  return (
    <ToastContext.Provider value={{ toasts, addToast, removeToast }}>
      {children}
      <ToastContainer />
    </ToastContext.Provider>
  )
}

function ToastContainer() {
  const { toasts, removeToast } = useToast()

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`
            px-4 py-3 rounded-lg shadow-lg backdrop-blur-sm border max-w-sm
            transform transition-all duration-300 ease-in-out
            ${
              toast.type === "success"
                ? "bg-green-500/20 border-green-500/30 text-green-400"
                : toast.type === "error"
                  ? "bg-red-500/20 border-red-500/30 text-red-400"
                  : "bg-blue-500/20 border-blue-500/30 text-blue-400"
            }
          `}
          onClick={() => removeToast(toast.id)}
        >
          <div className="flex items-center space-x-2">
            <div className="flex-1 text-sm font-medium">{toast.message}</div>
            <button onClick={() => removeToast(toast.id)} className="text-gray-400 hover:text-white transition-colors">
              ×
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}

export function useToast() {
  const context = useContext(ToastContext)
  if (context === undefined) {
    throw new Error("useToast must be used within a ToastProvider")
  }
  return context
}

// Helper functions for easier usage
export const toast = {
  success: (message: string) => {
    const context = useContext(ToastContext)
    if (context) {
      context.addToast(message, "success")
    }
  },
  error: (message: string) => {
    const context = useContext(ToastContext)
    if (context) {
      context.addToast(message, "error")
    }
  },
  info: (message: string) => {
    const context = useContext(ToastContext)
    if (context) {
      context.addToast(message, "info")
    }
  },
}
