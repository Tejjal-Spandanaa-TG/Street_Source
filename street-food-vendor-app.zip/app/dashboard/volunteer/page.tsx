"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  MapPin,
  Clock,
  Phone,
  Package,
  CheckCircle,
  Truck,
  Star,
  ArrowLeft,
  LogOut,
  DollarSign,
  Navigation,
  Timer,
  Award,
  TrendingUp,
  Calendar,
  Target,
  Zap,
} from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { useOrders } from "@/lib/orders-context"
import { suppliers, products } from "@/lib/mock-data"
import { useToast } from "@/lib/toast-context"

export default function VolunteerDashboard() {
  const { user, logout } = useAuth()
  const { orders, updateOrderStatus } = useOrders()
  const { addToast } = useToast()
  const [activeDeliveries, setActiveDeliveries] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState("dashboard")
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  // Get available delivery tasks (accepted orders without volunteers)
  const availableDeliveries = orders.filter((order) => order.status === "accepted" && !order.volunteerId)

  // Get volunteer's active deliveries
  const myDeliveries = orders.filter((order) => order.volunteerId === user?.id)

  const acceptDelivery = (orderId: string) => {
    const orderIndex = orders.findIndex((o) => o.id === orderId)
    if (orderIndex !== -1) {
      orders[orderIndex].volunteerId = user!.id
      updateOrderStatus(orderId, "in_transit")
      setActiveDeliveries((prev) => [...prev, orderId])
      addToast("Delivery accepted! Contact details shared with vendor.", "success")
    }
  }

  const updateDeliveryStatus = (orderId: string, status: "picked_up" | "delivered") => {
    updateOrderStatus(orderId, status === "picked_up" ? "in_transit" : "delivered")
    addToast(status === "picked_up" ? "Order picked up!" : "Order delivered successfully!", "success")
  }

  const getSupplierInfo = (supplierId: string) => {
    return suppliers.find((s) => s.id === supplierId)
  }

  const stats = {
    totalDeliveries: myDeliveries.filter((o) => o.status === "delivered").length,
    activeDeliveries: myDeliveries.filter((o) => o.status === "in_transit").length,
    todayEarnings: 350,
    weeklyEarnings: 2100,
    rating: 4.8,
    onTimeRate: 96,
    totalDistance: 245,
    avgDeliveryTime: 28,
  }

  const achievements = [
    {
      title: "Speed Demon",
      description: "Complete 10 deliveries in under 30 minutes",
      progress: 7,
      total: 10,
      icon: Zap,
    },
    {
      title: "Customer Favorite",
      description: "Maintain 4.8+ rating for 30 days",
      progress: 25,
      total: 30,
      icon: Star,
    },
    { title: "Distance Champion", description: "Cover 500km in deliveries", progress: 245, total: 500, icon: Target },
  ]

  const todaySchedule = [
    { time: "09:00", task: "Pickup from Delhi Spice House", status: "completed" },
    { time: "10:30", task: "Delivery to Raj's Chaat Corner", status: "completed" },
    { time: "14:00", task: "Pickup from Azadpur Mandi", status: "active" },
    { time: "15:30", task: "Delivery to Street Food Hub", status: "pending" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-teal-900 to-green-900 p-4">
      <div className="container mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => (window.location.href = "/")}
              variant="outline"
              size="sm"
              className="border-green-400 text-green-400 hover:bg-green-400 hover:text-white bg-transparent"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Home
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Volunteer Mission Control</h1>
              <p className="text-gray-300">Earn while making a difference in your community</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-green-400 font-bold">₹{stats.todayEarnings}</p>
              <p className="text-sm text-gray-400">Today's Earnings</p>
            </div>
            <Button
              onClick={logout}
              variant="outline"
              size="sm"
              className="border-red-400 text-red-400 hover:bg-red-400 hover:text-white bg-transparent"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-6 flex space-x-1 bg-black/20 p-1 rounded-lg">
          {[
            { id: "dashboard", label: "Dashboard", icon: TrendingUp },
            { id: "deliveries", label: "Deliveries", icon: Truck },
            { id: "earnings", label: "Earnings", icon: DollarSign },
            { id: "achievements", label: "Achievements", icon: Award },
          ].map((tab) => {
            const Icon = tab.icon
            return (
              <Button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                variant={activeTab === tab.id ? "default" : "ghost"}
                className={`flex-1 ${
                  activeTab === tab.id
                    ? "bg-green-500 text-white"
                    : "text-gray-400 hover:text-white hover:bg-green-500/20"
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {tab.label}
              </Button>
            )
          })}
        </div>

        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            {/* Performance Stats */}
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-8 w-8 text-green-400" />
                    <div>
                      <p className="text-2xl font-bold text-white">{stats.totalDeliveries}</p>
                      <p className="text-sm text-gray-400">Completed</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Star className="h-8 w-8 text-yellow-400" />
                    <div>
                      <p className="text-2xl font-bold text-white">{stats.rating}</p>
                      <p className="text-sm text-gray-400">Rating</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Timer className="h-8 w-8 text-purple-400" />
                    <div>
                      <p className="text-2xl font-bold text-white">{stats.onTimeRate}%</p>
                      <p className="text-sm text-gray-400">On Time</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-yellow-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <DollarSign className="h-8 w-8 text-yellow-400" />
                    <div>
                      <p className="text-2xl font-bold text-white">₹{stats.weeklyEarnings}</p>
                      <p className="text-sm text-gray-400">This Week</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              {/* Today's Schedule */}
              <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Calendar className="h-5 w-5" />
                    <span>Today's Schedule</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {todaySchedule.map((item, index) => (
                      <div key={index} className="flex items-center space-x-4 p-3 bg-black/20 rounded-lg">
                        <div className="text-green-400 font-mono text-sm">{item.time}</div>
                        <div className="flex-1">
                          <p className="text-white text-sm">{item.task}</p>
                        </div>
                        <Badge
                          className={`${
                            item.status === "completed"
                              ? "bg-green-500/20 text-green-400"
                              : item.status === "active"
                                ? "bg-blue-500/20 text-blue-400"
                                : "bg-gray-500/20 text-gray-400"
                          }`}
                        >
                          {item.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Live Stats */}
              <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Live Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Distance Today</span>
                      <span className="text-green-400 font-bold">{Math.floor(stats.totalDistance * 0.2)}km</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Avg Delivery Time</span>
                      <span className="text-blue-400 font-bold">{stats.avgDeliveryTime} min</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Active Since</span>
                      <span className="text-purple-400 font-bold">6:30 AM</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Current Time</span>
                      <span className="text-white font-mono">{currentTime.toLocaleTimeString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Deliveries Tab */}
        {activeTab === "deliveries" && (
          <div className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Available Deliveries */}
              <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center justify-between">
                    <span>Available Deliveries</span>
                    <Badge className="bg-green-500/20 text-green-400">{availableDeliveries.length} Available</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {availableDeliveries.map((order) => {
                      const firstItem = order.items[0]
                      const supplier = getSupplierInfo(
                        products.find((p) => p.id === firstItem.productId)?.supplierId || "",
                      )

                      return (
                        <div key={order.id} className="border border-green-500/20 rounded-lg p-4 bg-black/20">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h4 className="text-white font-medium">Delivery #{order.id.slice(-4)}</h4>
                              <p className="text-sm text-gray-400">
                                {order.items.length} items • ₹{order.total}
                              </p>
                            </div>
                            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">₹75 Reward</Badge>
                          </div>

                          <div className="space-y-2 mb-4">
                            <div className="flex items-center space-x-2 text-sm text-gray-300">
                              <MapPin className="h-4 w-4" />
                              <span>From: {supplier?.location}</span>
                            </div>
                            <div className="flex items-center space-x-2 text-sm text-gray-300">
                              <Navigation className="h-4 w-4" />
                              <span>To: {order.shopDetails?.name || "Vendor Location"}</span>
                            </div>
                            <div className="flex items-center space-x-2 text-sm text-gray-300">
                              <Clock className="h-4 w-4" />
                              <span>Est. delivery: {order.estimatedDelivery.toLocaleTimeString()}</span>
                            </div>
                          </div>

                          <Button
                            onClick={() => acceptDelivery(order.id)}
                            className="w-full bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white"
                          >
                            <Truck className="h-4 w-4 mr-2" />
                            Accept Delivery
                          </Button>
                        </div>
                      )
                    })}

                    {availableDeliveries.length === 0 && (
                      <div className="text-center py-8">
                        <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-400">No deliveries available right now</p>
                        <p className="text-sm text-gray-500">Check back in a few minutes</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* My Active Deliveries */}
              <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center justify-between">
                    <span>My Active Deliveries</span>
                    <Badge className="bg-blue-500/20 text-blue-400">{stats.activeDeliveries} Active</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {myDeliveries
                      .filter((order) => order.status !== "delivered")
                      .map((order) => {
                        const firstItem = order.items[0]
                        const supplier = getSupplierInfo(
                          products.find((p) => p.id === firstItem.productId)?.supplierId || "",
                        )

                        return (
                          <div key={order.id} className="border border-blue-500/20 rounded-lg p-4 bg-black/20">
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <h4 className="text-white font-medium">Delivery #{order.id.slice(-4)}</h4>
                                <p className="text-sm text-gray-400">
                                  {order.items.length} items • ₹{order.total}
                                </p>
                              </div>
                              <Badge
                                className={
                                  order.status === "in_transit"
                                    ? "bg-blue-500/20 text-blue-400 border-blue-500/30"
                                    : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                                }
                              >
                                {order.status === "in_transit" ? "In Transit" : "Accepted"}
                              </Badge>
                            </div>

                            <div className="space-y-2 mb-4">
                              <div className="flex items-center space-x-2 text-sm text-gray-300">
                                <MapPin className="h-4 w-4" />
                                <span>From: {supplier?.location}</span>
                              </div>
                              <div className="flex items-center space-x-2 text-sm text-gray-300">
                                <Phone className="h-4 w-4" />
                                <span>Supplier: {supplier?.phone}</span>
                              </div>
                              <div className="flex items-center space-x-2 text-sm text-gray-300">
                                <Clock className="h-4 w-4" />
                                <span>Est. delivery: {order.estimatedDelivery.toLocaleTimeString()}</span>
                              </div>
                            </div>

                            <div className="flex space-x-2">
                              {order.status === "accepted" && (
                                <Button
                                  onClick={() => updateDeliveryStatus(order.id, "picked_up")}
                                  className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
                                >
                                  Mark as Picked Up
                                </Button>
                              )}
                              {order.status === "in_transit" && (
                                <Button
                                  onClick={() => updateDeliveryStatus(order.id, "delivered")}
                                  className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                                >
                                  Mark as Delivered
                                </Button>
                              )}
                            </div>
                          </div>
                        )
                      })}

                    {myDeliveries.filter((order) => order.status !== "delivered").length === 0 && (
                      <div className="text-center py-8">
                        <Truck className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-400">No active deliveries</p>
                        <p className="text-sm text-gray-500">Accept a delivery to get started</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Earnings Tab */}
        {activeTab === "earnings" && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <DollarSign className="h-8 w-8 text-green-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">₹{stats.todayEarnings}</p>
                  <p className="text-sm text-gray-400">Today's Earnings</p>
                </CardContent>
              </Card>
              <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <TrendingUp className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">₹{stats.weeklyEarnings}</p>
                  <p className="text-sm text-gray-400">This Week</p>
                </CardContent>
              </Card>
              <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <Award className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">₹{stats.weeklyEarnings * 4}</p>
                  <p className="text-sm text-gray-400">This Month</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Earnings Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-black/20 rounded-lg">
                    <span className="text-gray-300">Base Delivery Fee</span>
                    <span className="text-green-400 font-bold">₹50 per delivery</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-black/20 rounded-lg">
                    <span className="text-gray-300">Distance Bonus</span>
                    <span className="text-blue-400 font-bold">₹5 per km</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-black/20 rounded-lg">
                    <span className="text-gray-300">On-Time Bonus</span>
                    <span className="text-purple-400 font-bold">₹25 per delivery</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-black/20 rounded-lg">
                    <span className="text-gray-300">Customer Rating Bonus</span>
                    <span className="text-yellow-400 font-bold">₹10 per 5-star</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Achievements Tab */}
        {activeTab === "achievements" && (
          <div className="space-y-6">
            <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Current Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievements.map((achievement, index) => {
                    const Icon = achievement.icon
                    const progress = (achievement.progress / achievement.total) * 100

                    return (
                      <div key={index} className="border border-green-500/20 rounded-lg p-4 bg-black/20">
                        <div className="flex items-start space-x-4">
                          <div className="p-2 bg-green-500/20 rounded-lg">
                            <Icon className="h-6 w-6 text-green-400" />
                          </div>
                          <div className="flex-1">
                            <h4 className="text-white font-medium mb-1">{achievement.title}</h4>
                            <p className="text-sm text-gray-400 mb-3">{achievement.description}</p>
                            <div className="flex items-center space-x-3">
                              <div className="flex-1 bg-gray-700 rounded-full h-2">
                                <div
                                  className="bg-gradient-to-r from-green-500 to-teal-500 h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${progress}%` }}
                                />
                              </div>
                              <span className="text-sm text-gray-400">
                                {achievement.progress}/{achievement.total}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
