"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Plus,
  Package,
  ShoppingBag,
  TrendingUp,
  Edit,
  Check,
  X,
  ArrowLeft,
  LogOut,
  DollarSign,
  Users,
  Clock,
  Star,
  Eye,
  BarChart3,
  Truck,
} from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { useOrders } from "@/lib/orders-context"
import { products } from "@/lib/mock-data"
import { useToast } from "@/lib/toast-context"
import Image from "next/image"

export default function SupplierDashboard() {
  const { user, logout } = useAuth()
  const { orders, updateOrderStatus } = useOrders()
  const { addToast } = useToast()
  const [showAddProduct, setShowAddProduct] = useState(false)
  const [activeTab, setActiveTab] = useState("overview")
  const [newProduct, setNewProduct] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    stock: "",
    image: "/placeholder.svg?height=100&width=100&text=Product",
  })

  // Get supplier's products and orders
  const supplierProducts = products.filter((p) => p.supplierId === user?.id)
  const supplierOrders = orders.filter((order) =>
    order.items.some((item) => products.find((p) => p.id === item.productId)?.supplierId === user?.id),
  )

  const handleAddProduct = () => {
    if (!newProduct.name || !newProduct.price || !newProduct.category) {
      addToast("Please fill in all required fields", "error")
      return
    }

    addToast("Product added successfully!", "success")
    setNewProduct({
      name: "",
      description: "",
      price: "",
      category: "",
      stock: "",
      image: "/placeholder.svg?height=100&width=100&text=Product",
    })
    setShowAddProduct(false)
  }

  const handleOrderAction = (orderId: string, action: "accept" | "reject") => {
    const newStatus = action === "accept" ? "accepted" : "rejected"
    updateOrderStatus(orderId, newStatus)
    addToast(`Order ${action}ed successfully!`, "success")
  }

  const stats = {
    totalProducts: supplierProducts.length,
    totalOrders: supplierOrders.length,
    pendingOrders: supplierOrders.filter((o) => o.status === "pending").length,
    revenue: supplierOrders.reduce((sum, order) => sum + order.total, 0),
    activeVendors: 12,
    avgRating: 4.7,
  }

  const recentActivity = [
    { type: "order", message: "New order from Raj's Chaat Corner", time: "2 min ago", status: "pending" },
    { type: "product", message: "Fresh Onions stock updated", time: "15 min ago", status: "success" },
    { type: "payment", message: "Payment received ₹2,500", time: "1 hour ago", status: "success" },
    { type: "order", message: "Order delivered to Delhi Street Hub", time: "2 hours ago", status: "completed" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-indigo-900 to-blue-900 p-4">
      <div className="container mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => (window.location.href = "/")}
              variant="outline"
              size="sm"
              className="border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white bg-transparent"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Home
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Supplier Control Center</h1>
              <p className="text-gray-300">Manage your products, orders, and grow your business</p>
            </div>
          </div>
          <Button
            onClick={logout}
            variant="outline"
            size="sm"
            className="border-red-400 text-red-400 hover:bg-red-400 hover:text-white bg-transparent"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        {/* Navigation Tabs */}
        <div className="mb-6 flex space-x-1 bg-black/20 p-1 rounded-lg">
          {[
            { id: "overview", label: "Overview", icon: BarChart3 },
            { id: "products", label: "Products", icon: Package },
            { id: "orders", label: "Orders", icon: ShoppingBag },
            { id: "analytics", label: "Analytics", icon: TrendingUp },
          ].map((tab) => {
            const Icon = tab.icon
            return (
              <Button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                variant={activeTab === tab.id ? "default" : "ghost"}
                className={`flex-1 ${
                  activeTab === tab.id
                    ? "bg-blue-500 text-white"
                    : "text-gray-400 hover:text-white hover:bg-blue-500/20"
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {tab.label}
              </Button>
            )
          })}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Package className="h-8 w-8 text-blue-400" />
                    <div>
                      <p className="text-2xl font-bold text-white">{stats.totalProducts}</p>
                      <p className="text-sm text-gray-400">Products Listed</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <DollarSign className="h-8 w-8 text-green-400" />
                    <div>
                      <p className="text-2xl font-bold text-white">₹{stats.revenue}</p>
                      <p className="text-sm text-gray-400">Total Revenue</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-yellow-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Users className="h-8 w-8 text-yellow-400" />
                    <div>
                      <p className="text-2xl font-bold text-white">{stats.activeVendors}</p>
                      <p className="text-sm text-gray-400">Active Vendors</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Star className="h-8 w-8 text-purple-400" />
                    <div>
                      <p className="text-2xl font-bold text-white">{stats.avgRating}</p>
                      <p className="text-sm text-gray-400">Avg Rating</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              {/* Recent Activity */}
              <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity.map((activity, index) => (
                      <div key={index} className="flex items-center space-x-3 p-3 bg-black/20 rounded-lg">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            activity.status === "pending"
                              ? "bg-yellow-400"
                              : activity.status === "success"
                                ? "bg-green-400"
                                : "bg-blue-400"
                          }`}
                        />
                        <div className="flex-1">
                          <p className="text-white text-sm">{activity.message}</p>
                          <p className="text-gray-400 text-xs">{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <Button
                      onClick={() => setActiveTab("products")}
                      className="bg-blue-500 hover:bg-blue-600 text-white h-20 flex-col"
                    >
                      <Plus className="h-6 w-6 mb-2" />
                      Add Product
                    </Button>
                    <Button
                      onClick={() => setActiveTab("orders")}
                      className="bg-green-500 hover:bg-green-600 text-white h-20 flex-col"
                    >
                      <Eye className="h-6 w-6 mb-2" />
                      View Orders
                    </Button>
                    <Button
                      onClick={() => setActiveTab("analytics")}
                      className="bg-purple-500 hover:bg-purple-600 text-white h-20 flex-col"
                    >
                      <BarChart3 className="h-6 w-6 mb-2" />
                      Analytics
                    </Button>
                    <Button
                      variant="outline"
                      className="border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white h-20 flex-col bg-transparent"
                    >
                      <Truck className="h-6 w-6 mb-2" />
                      Deliveries
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Products Tab */}
        {activeTab === "products" && (
          <div className="space-y-6">
            <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-white">Product Inventory</CardTitle>
                <Button
                  onClick={() => setShowAddProduct(!showAddProduct)}
                  className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add New Product
                </Button>
              </CardHeader>
              <CardContent>
                {showAddProduct && (
                  <div className="mb-6 p-4 border border-blue-500/20 rounded-lg bg-black/20">
                    <h3 className="text-white font-semibold mb-4">Add New Product</h3>
                    <div className="grid gap-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name" className="text-white">
                            Product Name
                          </Label>
                          <Input
                            id="name"
                            value={newProduct.name}
                            onChange={(e) => setNewProduct((prev) => ({ ...prev, name: e.target.value }))}
                            className="bg-black/20 border-blue-500/30 text-white"
                            placeholder="e.g., Fresh Onions"
                          />
                        </div>
                        <div>
                          <Label htmlFor="price" className="text-white">
                            Price (₹/kg)
                          </Label>
                          <Input
                            id="price"
                            type="number"
                            value={newProduct.price}
                            onChange={(e) => setNewProduct((prev) => ({ ...prev, price: e.target.value }))}
                            className="bg-black/20 border-blue-500/30 text-white"
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="description" className="text-white">
                          Description
                        </Label>
                        <Textarea
                          id="description"
                          value={newProduct.description}
                          onChange={(e) => setNewProduct((prev) => ({ ...prev, description: e.target.value }))}
                          className="bg-black/20 border-blue-500/30 text-white"
                          placeholder="Product description..."
                        />
                      </div>
                      <div className="flex space-x-2">
                        <Button onClick={handleAddProduct} className="bg-blue-500 hover:bg-blue-600 text-white">
                          Add Product
                        </Button>
                        <Button
                          onClick={() => setShowAddProduct(false)}
                          variant="outline"
                          className="border-gray-500 text-gray-400 hover:bg-gray-500 hover:text-white"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {supplierProducts.map((product) => (
                    <div key={product.id} className="border border-blue-500/20 rounded-lg p-4 bg-black/20">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={100}
                        height={100}
                        className="rounded-lg object-cover mx-auto mb-3"
                      />
                      <h4 className="text-white font-medium text-center mb-2">{product.name}</h4>
                      <p className="text-sm text-gray-400 text-center mb-3">{product.description}</p>
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-blue-400 font-semibold">₹{product.price}/kg</span>
                        <Badge
                          className={`${product.stock > 50 ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}
                        >
                          {product.stock}kg stock
                        </Badge>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white bg-transparent"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-red-400 text-red-400 hover:bg-red-400 hover:text-white bg-transparent"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Orders Tab */}
        {activeTab === "orders" && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <Card className="bg-black/40 border-yellow-500/20 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <Clock className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{stats.pendingOrders}</p>
                  <p className="text-sm text-gray-400">Pending Orders</p>
                </CardContent>
              </Card>
              <Card className="bg-black/40 border-green-500/20 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <Check className="h-8 w-8 text-green-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">
                    {supplierOrders.filter((o) => o.status === "delivered").length}
                  </p>
                  <p className="text-sm text-gray-400">Completed</p>
                </CardContent>
              </Card>
              <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
                <CardContent className="p-4 text-center">
                  <Truck className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">
                    {supplierOrders.filter((o) => o.status === "in_transit").length}
                  </p>
                  <p className="text-sm text-gray-400">In Transit</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Order Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {supplierOrders.map((order) => (
                    <div key={order.id} className="border border-blue-500/20 rounded-lg p-4 bg-black/20">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="text-white font-medium">Order #{order.id.slice(-4)}</h4>
                          <p className="text-sm text-gray-400">
                            {order.createdAt.toLocaleDateString()} at {order.createdAt.toLocaleTimeString()}
                          </p>
                        </div>
                        <Badge
                          className={`${
                            order.status === "pending"
                              ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                              : order.status === "delivered"
                                ? "bg-green-500/20 text-green-400 border-green-500/30"
                                : order.status === "in_transit"
                                  ? "bg-blue-500/20 text-blue-400 border-blue-500/30"
                                  : "bg-red-500/20 text-red-400 border-red-500/30"
                          }`}
                        >
                          {order.status === "in_transit" ? "In Transit" : order.status}
                        </Badge>
                      </div>

                      <div className="space-y-2 mb-4">
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between text-sm">
                            <span className="text-gray-300">
                              {item.productName} × {item.quantity}kg
                            </span>
                            <span className="text-blue-400">₹{item.price * item.quantity}</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-between items-center pt-3 border-t border-blue-500/20">
                        <span className="text-white font-semibold">Total: ₹{order.total}</span>
                        {order.status === "pending" && (
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              onClick={() => handleOrderAction(order.id, "accept")}
                              className="bg-green-500 hover:bg-green-600 text-white"
                            >
                              <Check className="h-4 w-4 mr-1" />
                              Accept
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleOrderAction(order.id, "reject")}
                              className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                            >
                              <X className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Revenue Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">This Month</span>
                      <span className="text-green-400 font-bold">₹{stats.revenue}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Last Month</span>
                      <span className="text-gray-300">₹{Math.floor(stats.revenue * 0.8)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Growth</span>
                      <span className="text-green-400">+25%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-blue-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Top Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {supplierProducts.slice(0, 3).map((product, index) => (
                      <div key={product.id} className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <p className="text-white font-medium">{product.name}</p>
                          <p className="text-sm text-gray-400">₹{product.price}/kg</p>
                        </div>
                        <Badge className="bg-green-500/20 text-green-400">
                          {Math.floor(Math.random() * 50) + 10} sold
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
