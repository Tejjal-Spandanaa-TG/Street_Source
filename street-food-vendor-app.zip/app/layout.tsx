import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { AuthProvider } from "@/lib/auth-context"
import { OrdersProvider } from "@/lib/orders-context"
import { ToastProvider } from "@/lib/toast-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "StreetSource - Connect Street Food Vendors & Suppliers",
  description:
    "Trusted, affordable raw materials for street food vendors. Connect with verified suppliers and get volunteer delivery support.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <OrdersProvider>
            <ToastProvider>{children}</ToastProvider>
          </OrdersProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
