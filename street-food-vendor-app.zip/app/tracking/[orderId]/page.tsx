"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  MapPin,
  Clock,
  Phone,
  Star,
  Package,
  Truck,
  CheckCircle,
  User,
  MessageCircle,
  Navigation,
  Calendar,
  Store,
  ArrowLeft,
} from "lucide-react"
import { useOrders } from "@/lib/orders-context"
import { useAuth } from "@/lib/auth-context"
import { suppliers, products, volunteers } from "@/lib/mock-data"
import { useToast } from "@/lib/toast-context"
import Image from "next/image"

export default function OrderTrackingPage() {
  const params = useParams()
  const orderId = params.orderId as string
  const { orders } = useOrders()
  const { user } = useAuth()
  const { addToast } = useToast()
  const [currentTime, setCurrentTime] = useState(new Date())

  const order = orders.find((o) => o.id === orderId)
  const volunteer = order?.volunteerId ? volunteers.find((v) => v.id === order.volunteerId) : null

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  if (!order) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
          <CardContent className="p-8 text-center">
            <h1 className="text-2xl font-bold text-white mb-4">Order Not Found</h1>
            <p className="text-gray-400">The order you're looking for doesn't exist.</p>
            <Button
              onClick={() => (window.location.href = "/")}
              className="mt-4 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
            >
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const getStatusSteps = () => {
    const steps = [
      { key: "pending", label: "Order Placed", icon: Package, completed: true },
      { key: "accepted", label: "Order Accepted", icon: CheckCircle, completed: order.status !== "pending" },
      { key: "assigned", label: "Volunteer Assigned", icon: User, completed: !!order.volunteerId },
      {
        key: "picked_up",
        label: "Order Picked Up",
        icon: Truck,
        completed: ["in_transit", "delivered"].includes(order.status),
      },
      { key: "in_transit", label: "Out for Delivery", icon: Navigation, completed: order.status === "delivered" },
      { key: "delivered", label: "Delivered", icon: CheckCircle, completed: order.status === "delivered" },
    ]
    return steps
  }

  const getEstimatedTime = () => {
    const now = new Date()
    const timeDiff = order.estimatedDelivery.getTime() - now.getTime()

    if (timeDiff <= 0) return "Delivered"

    const hours = Math.floor(timeDiff / (1000 * 60 * 60))
    const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60))

    if (hours > 0) {
      return `${hours}h ${minutes}m remaining`
    }
    return `${minutes}m remaining`
  }

  const callVolunteer = () => {
    if (volunteer) {
      addToast(`Calling ${volunteer.name}...`, "info")
    }
  }

  const messageVolunteer = () => {
    if (volunteer) {
      addToast(`Opening chat with ${volunteer.name}...`, "info")
    }
  }

  const steps = getStatusSteps()
  const currentStepIndex = steps.findIndex((step) => !step.completed)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <div className="container mx-auto max-w-4xl">
        {/* Header with Back Button */}
        <div className="mb-8 flex items-center space-x-4">
          <Button
            onClick={() => window.history.back()}
            variant="outline"
            size="sm"
            className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white bg-transparent"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Track Your Order</h1>
            <p className="text-gray-300">
              Order #{order.id} • Placed on {order.createdAt.toLocaleDateString()}
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Tracking Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Delivery Destination */}
            {order.shopDetails && (
              <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Store className="h-5 w-5" />
                    <span>Delivery Destination</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <h3 className="text-lg font-semibold text-purple-400">{order.shopDetails.name}</h3>
                      <p className="text-gray-300">{order.shopDetails.address}</p>
                      {order.shopDetails.landmark && (
                        <p className="text-sm text-gray-400">Near: {order.shopDetails.landmark}</p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Status Timeline */}
            <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Package className="h-5 w-5" />
                  <span>Order Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {steps.map((step, index) => {
                    const Icon = step.icon
                    const isActive = index === currentStepIndex
                    const isCompleted = step.completed

                    return (
                      <div key={step.key} className="flex items-center space-x-4">
                        <div
                          className={`
                          flex items-center justify-center w-10 h-10 rounded-full border-2 transition-colors
                          ${
                            isCompleted
                              ? "bg-green-500 border-green-500 text-white"
                              : isActive
                                ? "bg-purple-500 border-purple-500 text-white animate-pulse"
                                : "bg-gray-700 border-gray-600 text-gray-400"
                          }
                        `}
                        >
                          <Icon className="h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <p className={`font-medium ${isCompleted || isActive ? "text-white" : "text-gray-400"}`}>
                            {step.label}
                          </p>
                          {isActive && <p className="text-sm text-purple-400">In Progress...</p>}
                          {isCompleted && step.key === "delivered" && (
                            <p className="text-sm text-green-400">
                              Completed at {order.estimatedDelivery.toLocaleTimeString()}
                            </p>
                          )}
                        </div>
                        {isActive && (
                          <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">Current</Badge>
                        )}
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Google Maps Integration */}
            {volunteer && order.status === "in_transit" && order.shopDetails && (
              <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <MapPin className="h-5 w-5" />
                    <span>Live Location Tracking</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-800 rounded-lg overflow-hidden mb-4">
                    <iframe
                      src={`https://www.google.com/maps/embed/v1/directions?key=YOUR_API_KEY&origin=${order.shopDetails.coordinates.lat},${order.shopDetails.coordinates.lng}&destination=${order.shopDetails.coordinates.lat + 0.01},${order.shopDetails.coordinates.lng + 0.01}&mode=driving`}
                      width="100%"
                      height="300"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      className="rounded-lg"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                      <span className="text-white">Live tracking active</span>
                    </div>
                    <span className="text-purple-400 font-medium">{getEstimatedTime()}</span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Order Items */}
            <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Order Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {order.items.map((item, index) => {
                    const product = products.find((p) => p.id === item.productId)
                    const supplier = suppliers.find((s) => s.id === item.supplierId)

                    return (
                      <div
                        key={index}
                        className="flex items-center space-x-4 p-3 border border-purple-500/20 rounded-lg"
                      >
                        <Image
                          src={product?.image || "/placeholder.svg"}
                          alt={item.productName}
                          width={60}
                          height={60}
                          className="rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="text-white font-medium">{item.productName}</h4>
                          <p className="text-sm text-gray-400">From: {supplier?.name}</p>
                          <p className="text-sm text-gray-400">Quantity: {item.quantity}kg</p>
                        </div>
                        <div className="text-right">
                          <p className="text-purple-400 font-semibold">₹{item.price * item.quantity}</p>
                          <p className="text-sm text-gray-400">₹{item.price}/kg</p>
                        </div>
                      </div>
                    )
                  })}
                  <div className="border-t border-purple-500/20 pt-4">
                    <div className="flex justify-between items-center">
                      <span className="text-white font-semibold text-lg">Total Amount:</span>
                      <span className="text-purple-400 font-bold text-xl">₹{order.total}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Delivery Time */}
            <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Clock className="h-5 w-5" />
                  <span>Delivery Info</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-400">Estimated Delivery</p>
                    <p className="text-white font-medium">{order.estimatedDelivery.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Time Remaining</p>
                    <p className="text-purple-400 font-medium">{getEstimatedTime()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Current Time</p>
                    <p className="text-white">{currentTime.toLocaleTimeString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Volunteer Details */}
            {volunteer && (
              <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <User className="h-5 w-5" />
                    <span>Your Delivery Partner</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={volunteer.avatar || "/placeholder.svg"} alt={volunteer.name} />
                        <AvatarFallback className="bg-purple-500 text-white">
                          {volunteer.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="text-white font-medium">{volunteer.name}</h4>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-400">
                            {volunteer.rating} ({volunteer.totalDeliveries} deliveries)
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <Phone className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-300">{volunteer.phone}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Truck className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-300">{volunteer.vehicleType}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className="text-gray-300">Joined {volunteer.joinedDate}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-black/20 rounded-lg p-2">
                        <p className="text-lg font-bold text-green-400">{volunteer.totalDeliveries}</p>
                        <p className="text-xs text-gray-400">Deliveries</p>
                      </div>
                      <div className="bg-black/20 rounded-lg p-2">
                        <p className="text-lg font-bold text-blue-400">{volunteer.onTimePercentage}%</p>
                        <p className="text-xs text-gray-400">On Time</p>
                      </div>
                      <div className="bg-black/20 rounded-lg p-2">
                        <p className="text-lg font-bold text-purple-400">{volunteer.experience}</p>
                        <p className="text-xs text-gray-400">Experience</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Button onClick={callVolunteer} className="w-full bg-green-500 hover:bg-green-600 text-white">
                        <Phone className="h-4 w-4 mr-2" />
                        Call {volunteer.name.split(" ")[0]}
                      </Button>
                      <Button
                        onClick={messageVolunteer}
                        variant="outline"
                        className="w-full border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white bg-transparent"
                      >
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Message
                      </Button>
                    </div>

                    {volunteer.specializations && volunteer.specializations.length > 0 && (
                      <div>
                        <p className="text-sm text-gray-400 mb-2">Specializations:</p>
                        <div className="flex flex-wrap gap-1">
                          {volunteer.specializations.map((spec, index) => (
                            <Badge
                              key={index}
                              className="bg-purple-500/20 text-purple-400 border-purple-500/30 text-xs"
                            >
                              {spec}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Support */}
            <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Need Help?</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white bg-transparent"
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Contact Support
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-gray-500 text-gray-400 hover:bg-gray-500 hover:text-white bg-transparent"
                  >
                    Report Issue
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
