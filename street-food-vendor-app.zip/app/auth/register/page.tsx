"use client"

import type React from "react"
import { useSearchParams } from "next/navigation"
import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Utensils, Eye, EyeOff, User, Store, Truck, ArrowLeft } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/lib/toast-context"

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "",
    phone: "",
    address: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const { register, user } = useAuth()
  const { addToast } = useToast()
  const searchParams = useSearchParams()

  useEffect(() => {
    const roleParam = searchParams.get("role")
    if (roleParam && ["vendor", "supplier", "volunteer"].includes(roleParam)) {
      setFormData((prev) => ({ ...prev, role: roleParam }))
    }
  }, [searchParams])

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      switch (user.role) {
        case "vendor":
          window.location.href = "/dashboard/vendor"
          break
        case "supplier":
          window.location.href = "/dashboard/supplier"
          break
        case "volunteer":
          window.location.href = "/dashboard/volunteer"
          break
        default:
          window.location.href = "/"
      }
    }
  }, [user])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      addToast("Passwords do not match", "error")
      return
    }

    if (formData.password.length < 6) {
      addToast("Password must be at least 6 characters", "error")
      return
    }

    setLoading(true)

    try {
      const success = await register(formData)
      if (success) {
        addToast("Registration successful! Welcome to StreetSource!", "success")

        setTimeout(() => {
          switch (formData.role) {
            case "vendor":
              window.location.href = "/dashboard/vendor"
              break
            case "supplier":
              window.location.href = "/dashboard/supplier"
              break
            case "volunteer":
              window.location.href = "/dashboard/volunteer"
              break
            default:
              window.location.href = "/"
          }
        }, 1000)
      } else {
        addToast("Registration failed. Please try again.", "error")
      }
    } catch (error) {
      addToast("Registration failed. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  // Don't render if user is already logged in
  if (user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
          <CardContent className="p-8 text-center">
            <h1 className="text-2xl font-bold text-white mb-4">Redirecting...</h1>
            <p className="text-gray-400">You are already logged in.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="absolute top-4 left-4">
        <Button
          onClick={() => (window.location.href = "/")}
          variant="outline"
          size="sm"
          className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white bg-transparent"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Button>
      </div>
      <Card className="w-full max-w-md bg-black/40 border-purple-500/20 backdrop-blur-sm">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Utensils className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">StreetSource</span>
          </div>
          <CardTitle className="text-2xl text-white">Join StreetSource</CardTitle>
          <p className="text-gray-400">Create your account to get started</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-white">
                Full Name
              </Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                className="bg-black/20 border-purple-500/30 text-white placeholder:text-gray-400"
                placeholder="Enter your full name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                className="bg-black/20 border-purple-500/30 text-white placeholder:text-gray-400"
                placeholder="Enter your email"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role" className="text-white">
                I am a
              </Label>
              <Select
                value={formData.role}
                onValueChange={(value) => setFormData((prev) => ({ ...prev, role: value }))}
              >
                <SelectTrigger className="bg-black/20 border-purple-500/30 text-white">
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-purple-500/30">
                  <SelectItem value="vendor" className="text-white hover:bg-purple-500/20">
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4" />
                      <span>Vendor (Street Food Seller)</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="supplier" className="text-white hover:bg-purple-500/20">
                    <div className="flex items-center space-x-2">
                      <Store className="h-4 w-4" />
                      <span>Supplier (Raw Material Seller)</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="volunteer" className="text-white hover:bg-purple-500/20">
                    <div className="flex items-center space-x-2">
                      <Truck className="h-4 w-4" />
                      <span>Volunteer (Delivery Person)</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="text-white">
                Phone Number
              </Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
                className="bg-black/20 border-purple-500/30 text-white placeholder:text-gray-400"
                placeholder="Enter your phone number"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address" className="text-white">
                Address
              </Label>
              <Input
                id="address"
                type="text"
                value={formData.address}
                onChange={(e) => setFormData((prev) => ({ ...prev, address: e.target.value }))}
                className="bg-black/20 border-purple-500/30 text-white placeholder:text-gray-400"
                placeholder="Enter your address"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-white">
                Password
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData((prev) => ({ ...prev, password: e.target.value }))}
                  className="bg-black/20 border-purple-500/30 text-white placeholder:text-gray-400 pr-10"
                  placeholder="Create a password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-white">
                Confirm Password
              </Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                  className="bg-black/20 border-purple-500/30 text-white placeholder:text-gray-400 pr-10"
                  placeholder="Confirm your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg shadow-purple-500/25"
              disabled={loading}
            >
              {loading ? "Creating Account..." : "Create Account"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-400">
              Already have an account?{" "}
              <Link href="/auth/login" className="text-purple-400 hover:text-purple-300">
                Sign in
              </Link>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
