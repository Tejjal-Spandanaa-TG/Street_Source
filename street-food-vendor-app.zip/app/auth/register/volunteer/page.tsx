"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Utensils, Eye, EyeOff, ArrowLeft, Truck, MapPin, Clock } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/lib/toast-context"

export default function VolunteerRegisterPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    address: "",
    vehicleType: "",
    licenseNumber: "",
    availability: "",
    experience: "",
    emergencyContact: "",
    emergencyPhone: "",
    description: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const { register } = useAuth()
  const { addToast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      addToast("Passwords do not match", "error")
      return
    }

    if (formData.password.length < 6) {
      addToast("Password must be at least 6 characters", "error")
      return
    }

    setLoading(true)

    try {
      const volunteerData = {
        ...formData,
        role: "volunteer",
      }
      const success = await register(volunteerData)
      if (success) {
        addToast("Welcome to StreetSource! Your volunteer account is ready!", "success")
        setTimeout(() => {
          window.location.href = "/dashboard/volunteer"
        }, 1000)
      } else {
        addToast("Registration failed. Please try again.", "error")
      }
    } catch (error) {
      addToast("Registration failed. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-teal-900 to-green-900 flex items-center justify-center p-4">
      <div className="absolute top-4 left-4">
        <Button
          onClick={() => (window.location.href = "/")}
          variant="outline"
          size="sm"
          className="border-green-400 text-green-400 hover:bg-green-400 hover:text-white bg-transparent"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Button>
      </div>

      <Card className="w-full max-w-2xl bg-black/40 border-green-500/20 backdrop-blur-sm">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Utensils className="h-8 w-8 text-green-400" />
            <span className="text-2xl font-bold text-white">StreetSource</span>
          </div>
          <CardTitle className="text-3xl text-white flex items-center justify-center space-x-2">
            <Truck className="h-8 w-8 text-green-400" />
            <span>Join as a Volunteer</span>
          </CardTitle>
          <p className="text-gray-300">Earn money while supporting local street food vendors</p>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-green-400 border-b border-green-500/20 pb-2">
                Personal Information
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-white">
                    Full Name *
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                    className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                    placeholder="Your full name"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-white">
                    Phone Number *
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
                    className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                    placeholder="+91 9876543210"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">
                  Email Address *
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                  placeholder="your.email@example.com"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="text-white flex items-center space-x-1">
                  <MapPin className="h-4 w-4" />
                  <span>Current Address *</span>
                </Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData((prev) => ({ ...prev, address: e.target.value }))}
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                  placeholder="Complete address with area, city, and pincode"
                  rows={3}
                  required
                />
              </div>
            </div>

            {/* Vehicle & Delivery Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-green-400 border-b border-green-500/20 pb-2">
                Vehicle & Delivery Information
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vehicleType" className="text-white">
                    Vehicle Type *
                  </Label>
                  <Select
                    value={formData.vehicleType}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, vehicleType: value }))}
                  >
                    <SelectTrigger className="bg-black/20 border-green-500/30 text-white">
                      <SelectValue placeholder="Select your vehicle" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-green-500/30">
                      <SelectItem value="bicycle" className="text-white">
                        Bicycle
                      </SelectItem>
                      <SelectItem value="motorcycle" className="text-white">
                        Motorcycle
                      </SelectItem>
                      <SelectItem value="scooter" className="text-white">
                        Scooter
                      </SelectItem>
                      <SelectItem value="auto" className="text-white">
                        Auto Rickshaw
                      </SelectItem>
                      <SelectItem value="car" className="text-white">
                        Car
                      </SelectItem>
                      <SelectItem value="van" className="text-white">
                        Van/Tempo
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="licenseNumber" className="text-white">
                    License Number
                  </Label>
                  <Input
                    id="licenseNumber"
                    type="text"
                    value={formData.licenseNumber}
                    onChange={(e) => setFormData((prev) => ({ ...prev, licenseNumber: e.target.value }))}
                    className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                    placeholder="DL number (if applicable)"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="availability" className="text-white flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>Availability *</span>
                </Label>
                <Select
                  value={formData.availability}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, availability: value }))}
                >
                  <SelectTrigger className="bg-black/20 border-green-500/30 text-white">
                    <SelectValue placeholder="When can you deliver?" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-green-500/30">
                    <SelectItem value="morning" className="text-white">
                      Morning (6 AM - 12 PM)
                    </SelectItem>
                    <SelectItem value="afternoon" className="text-white">
                      Afternoon (12 PM - 6 PM)
                    </SelectItem>
                    <SelectItem value="evening" className="text-white">
                      Evening (6 PM - 10 PM)
                    </SelectItem>
                    <SelectItem value="flexible" className="text-white">
                      Flexible Hours
                    </SelectItem>
                    <SelectItem value="weekend" className="text-white">
                      Weekends Only
                    </SelectItem>
                    <SelectItem value="fulltime" className="text-white">
                      Full Time
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="experience" className="text-white">
                  Delivery Experience
                </Label>
                <Input
                  id="experience"
                  type="text"
                  value={formData.experience}
                  onChange={(e) => setFormData((prev) => ({ ...prev, experience: e.target.value }))}
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                  placeholder="e.g., 2 years with food delivery apps"
                />
              </div>
            </div>

            {/* Emergency Contact */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-green-400 border-b border-green-500/20 pb-2">
                Emergency Contact
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="emergencyContact" className="text-white">
                    Emergency Contact Name *
                  </Label>
                  <Input
                    id="emergencyContact"
                    type="text"
                    value={formData.emergencyContact}
                    onChange={(e) => setFormData((prev) => ({ ...prev, emergencyContact: e.target.value }))}
                    className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                    placeholder="Family member or friend"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="emergencyPhone" className="text-white">
                    Emergency Contact Phone *
                  </Label>
                  <Input
                    id="emergencyPhone"
                    type="tel"
                    value={formData.emergencyPhone}
                    onChange={(e) => setFormData((prev) => ({ ...prev, emergencyPhone: e.target.value }))}
                    className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                    placeholder="+91 9876543210"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-white">
                  Why do you want to volunteer?
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                  className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400"
                  placeholder="Tell us about your motivation to help street food vendors"
                  rows={3}
                />
              </div>
            </div>

            {/* Password Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-green-400 border-b border-green-500/20 pb-2">
                Account Security
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-white">
                    Password *
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={formData.password}
                      onChange={(e) => setFormData((prev) => ({ ...prev, password: e.target.value }))}
                      className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400 pr-10"
                      placeholder="Create a strong password"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-white">
                    Confirm Password *
                  </Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                      className="bg-black/20 border-green-500/30 text-white placeholder:text-gray-400 pr-10"
                      placeholder="Confirm your password"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                    >
                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white shadow-lg shadow-green-500/25 py-3 text-lg"
              disabled={loading}
            >
              {loading ? "Creating Your Volunteer Account..." : "Start Earning as a Volunteer"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-400">
              Already have an account?{" "}
              <Link href="/auth/login" className="text-green-400 hover:text-green-300">
                Sign in
              </Link>
            </p>
          </div>

          <div className="mt-4 p-4 bg-green-500/10 rounded-lg border border-green-500/20">
            <h4 className="text-green-400 font-semibold mb-2">What you'll get as a Volunteer:</h4>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Earn ₹50-100 per delivery with flexible working hours</li>
              <li>• Support local street food vendors in your community</li>
              <li>• Easy-to-use app with GPS navigation and order tracking</li>
              <li>• Weekly payments and performance bonuses</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
