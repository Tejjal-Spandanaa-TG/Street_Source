"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Utensils, Eye, EyeOff, ArrowLeft, Package, MapPin } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/lib/toast-context"

export default function SupplierRegisterPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    address: "",
    businessName: "",
    businessType: "",
    experience: "",
    specialization: "",
    capacity: "",
    description: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const { register } = useAuth()
  const { addToast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      addToast("Passwords do not match", "error")
      return
    }

    if (formData.password.length < 6) {
      addToast("Password must be at least 6 characters", "error")
      return
    }

    setLoading(true)

    try {
      const supplierData = {
        ...formData,
        role: "supplier",
      }
      const success = await register(supplierData)
      if (success) {
        addToast("Welcome to StreetSource! Your supplier account is ready!", "success")
        setTimeout(() => {
          window.location.href = "/dashboard/supplier"
        }, 1000)
      } else {
        addToast("Registration failed. Please try again.", "error")
      }
    } catch (error) {
      addToast("Registration failed. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-indigo-900 to-blue-900 flex items-center justify-center p-4">
      <div className="absolute top-4 left-4">
        <Button
          onClick={() => (window.location.href = "/")}
          variant="outline"
          size="sm"
          className="border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white bg-transparent"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Button>
      </div>

      <Card className="w-full max-w-2xl bg-black/40 border-blue-500/20 backdrop-blur-sm">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Utensils className="h-8 w-8 text-blue-400" />
            <span className="text-2xl font-bold text-white">StreetSource</span>
          </div>
          <CardTitle className="text-3xl text-white flex items-center justify-center space-x-2">
            <Package className="h-8 w-8 text-blue-400" />
            <span>Join as a Supplier</span>
          </CardTitle>
          <p className="text-gray-300">Connect with street food vendors and grow your distribution network</p>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-blue-400 border-b border-blue-500/20 pb-2">
                Personal Information
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-white">
                    Full Name *
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                    className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400"
                    placeholder="Your full name"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-white">
                    Phone Number *
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
                    className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400"
                    placeholder="+91 9876543210"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">
                  Email Address *
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                  className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400"
                  placeholder="your.email@example.com"
                  required
                />
              </div>
            </div>

            {/* Business Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-blue-400 border-b border-blue-500/20 pb-2">
                Business Information
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="businessName" className="text-white">
                    Business Name *
                  </Label>
                  <Input
                    id="businessName"
                    type="text"
                    value={formData.businessName}
                    onChange={(e) => setFormData((prev) => ({ ...prev, businessName: e.target.value }))}
                    className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400"
                    placeholder="e.g., Delhi Spice House"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessType" className="text-white">
                    Business Type *
                  </Label>
                  <Select
                    value={formData.businessType}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, businessType: value }))}
                  >
                    <SelectTrigger className="bg-black/20 border-blue-500/30 text-white">
                      <SelectValue placeholder="Select business type" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-blue-500/30">
                      <SelectItem value="wholesaler" className="text-white">
                        Wholesaler
                      </SelectItem>
                      <SelectItem value="distributor" className="text-white">
                        Distributor
                      </SelectItem>
                      <SelectItem value="manufacturer" className="text-white">
                        Manufacturer
                      </SelectItem>
                      <SelectItem value="farmer" className="text-white">
                        Farmer/Producer
                      </SelectItem>
                      <SelectItem value="retailer" className="text-white">
                        Retailer
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="text-white flex items-center space-x-1">
                  <MapPin className="h-4 w-4" />
                  <span>Business Address *</span>
                </Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData((prev) => ({ ...prev, address: e.target.value }))}
                  className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400"
                  placeholder="Complete address with area, city, and pincode"
                  rows={3}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="specialization" className="text-white">
                    Specialization *
                  </Label>
                  <Select
                    value={formData.specialization}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, specialization: value }))}
                  >
                    <SelectTrigger className="bg-black/20 border-blue-500/30 text-white">
                      <SelectValue placeholder="What do you supply?" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-blue-500/30">
                      <SelectItem value="vegetables" className="text-white">
                        Fresh Vegetables
                      </SelectItem>
                      <SelectItem value="spices" className="text-white">
                        Spices & Seasonings
                      </SelectItem>
                      <SelectItem value="grains" className="text-white">
                        Grains & Cereals
                      </SelectItem>
                      <SelectItem value="dairy" className="text-white">
                        Dairy Products
                      </SelectItem>
                      <SelectItem value="oils" className="text-white">
                        Cooking Oils
                      </SelectItem>
                      <SelectItem value="mixed" className="text-white">
                        Mixed Products
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experience" className="text-white">
                    Years of Experience
                  </Label>
                  <Input
                    id="experience"
                    type="text"
                    value={formData.experience}
                    onChange={(e) => setFormData((prev) => ({ ...prev, experience: e.target.value }))}
                    className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400"
                    placeholder="e.g., 10 years"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="capacity" className="text-white">
                  Supply Capacity
                </Label>
                <Input
                  id="capacity"
                  type="text"
                  value={formData.capacity}
                  onChange={(e) => setFormData((prev) => ({ ...prev, capacity: e.target.value }))}
                  className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400"
                  placeholder="e.g., 1000 kg per day"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-white">
                  Tell us about your business
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                  className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400"
                  placeholder="What products do you supply? What makes your business unique?"
                  rows={3}
                />
              </div>
            </div>

            {/* Password Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-blue-400 border-b border-blue-500/20 pb-2">Account Security</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-white">
                    Password *
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={formData.password}
                      onChange={(e) => setFormData((prev) => ({ ...prev, password: e.target.value }))}
                      className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400 pr-10"
                      placeholder="Create a strong password"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-white">
                    Confirm Password *
                  </Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                      className="bg-black/20 border-blue-500/30 text-white placeholder:text-gray-400 pr-10"
                      placeholder="Confirm your password"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                    >
                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white shadow-lg shadow-blue-500/25 py-3 text-lg"
              disabled={loading}
            >
              {loading ? "Creating Your Supplier Account..." : "Start Supplying to Street Vendors"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-400">
              Already have an account?{" "}
              <Link href="/auth/login" className="text-blue-400 hover:text-blue-300">
                Sign in
              </Link>
            </p>
          </div>

          <div className="mt-4 p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
            <h4 className="text-blue-400 font-semibold mb-2">What you'll get as a Supplier:</h4>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Direct access to street food vendors across your city</li>
              <li>• Streamlined order management and inventory tracking</li>
              <li>• Reliable payment processing and business analytics</li>
              <li>• Volunteer delivery network to reach more customers</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
