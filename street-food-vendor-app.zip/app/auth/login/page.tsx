"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Utensils, Eye, EyeOff, ArrowLeft } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/lib/toast-context"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const { login, user } = useAuth()
  const router = useRouter()
  const { addToast } = useToast()

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      switch (user.role) {
        case "vendor":
          window.location.href = "/dashboard/vendor"
          break
        case "supplier":
          window.location.href = "/dashboard/supplier"
          break
        case "volunteer":
          window.location.href = "/dashboard/volunteer"
          break
        default:
          window.location.href = "/"
      }
    }
  }, [user])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const success = await login(email, password)
      if (success) {
        addToast("Login successful! Welcome back!", "success")

        // Get user from localStorage to determine redirect
        const storedUser = localStorage.getItem("user")
        if (storedUser) {
          const user = JSON.parse(storedUser)
          setTimeout(() => {
            switch (user.role) {
              case "vendor":
                window.location.href = "/dashboard/vendor"
                break
              case "supplier":
                window.location.href = "/dashboard/supplier"
                break
              case "volunteer":
                window.location.href = "/dashboard/volunteer"
                break
              default:
                window.location.href = "/"
            }
          }, 1000)
        }
      } else {
        addToast("Invalid credentials. Please try again.", "error")
      }
    } catch (error) {
      addToast("Login failed. Please try again.", "error")
    } finally {
      setLoading(false)
    }
  }

  // Don't render if user is already logged in
  if (user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm">
          <CardContent className="p-8 text-center">
            <h1 className="text-2xl font-bold text-white mb-4">Redirecting...</h1>
            <p className="text-gray-400">You are already logged in.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="absolute top-4 left-4">
        <Button
          onClick={() => (window.location.href = "/")}
          variant="outline"
          size="sm"
          className="border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-white bg-transparent"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Button>
      </div>
      <Card className="w-full max-w-md bg-black/40 border-purple-500/20 backdrop-blur-sm">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Utensils className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">StreetSource</span>
          </div>
          <CardTitle className="text-2xl text-white">Welcome Back</CardTitle>
          <p className="text-gray-400">Sign in to your account</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-black/20 border-purple-500/30 text-white placeholder:text-gray-400"
                placeholder="Enter your email"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-white">
                Password
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-black/20 border-purple-500/30 text-white placeholder:text-gray-400 pr-10"
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg shadow-purple-500/25"
              disabled={loading}
            >
              {loading ? "Signing in..." : "Sign In"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-400">
              Don't have an account?{" "}
              <Link href="/auth/register" className="text-purple-400 hover:text-purple-300">
                Sign up
              </Link>
            </p>
          </div>

          <div className="mt-4 text-center">
            <p className="text-sm text-gray-500">
              Demo credentials: vendor@demo.com / supplier@demo.com / volunteer@demo.com (password: demo123)
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
