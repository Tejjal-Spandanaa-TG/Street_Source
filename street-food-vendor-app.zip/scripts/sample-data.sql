-- Sample data for StreetSource application
USE streetsource;

-- Insert sample users
INSERT INTO users (id, name, email, password_hash, role, phone, address, shop_name, shop_type, rating, total_orders) VALUES
('vendor-1', 'Raj Kumar', 'vendor@demo.com', '$2b$10$example_hash', 'vendor', '+91 9876543210', 'Shop 15, Connaught Place, New Delhi - 110001', 'Raj\'s Chaat Corner', 'Chaat, Snacks', 4.5, 25),
('vendor-2', 'Priya Sharma', 'vendor2@demo.com', '$2b$10$example_hash', 'vendor', '+91 9876543211', 'Block A, Karol Bagh Market, New Delhi - 110005', 'Delhi Street Food Hub', 'Mixed Street Food', 4.3, 18);

INSERT INTO users (id, name, email, password_hash, role, phone, address, business_name, business_type, specialization, rating, total_orders) VALUES
('supplier-1', 'Ramesh Vegetables', 'supplier@demo.com', '$2b$10$example_hash', 'supplier', '+91 9876543212', 'Azadpur Mandi, Delhi - 110033', 'Ramesh Fresh Vegetables', 'wholesaler', 'vegetables', 4.8, 156),
('supplier-2', 'Delhi Spice House', 'supplier2@demo.com', '$2b$10$example_hash', 'supplier', '+91 9876543213', 'Khari Baoli, Delhi - 110006', 'Delhi Spice House', 'wholesaler', 'spices', 4.9, 203),
('supplier-3', 'Ghazipur Grains', 'supplier3@demo.com', '$2b$10$example_hash', 'supplier', '+91 9876543214', 'Ghazipur Mandi, Delhi - 110096', 'Ghazipur Grain Suppliers', 'distributor', 'grains', 4.6, 89);

INSERT INTO users (id, name, email, password_hash, role, phone, address, vehicle_type, license_number, availability, emergency_contact, emergency_phone, rating, total_deliveries, on_time_percentage) VALUES
('volunteer-1', 'Amit Singh', 'volunteer@demo.com', '$2b$10$example_hash', 'volunteer', '+91 9876543215', 'Karol Bagh, New Delhi - 110005', 'motorcycle', 'DL-1234567890', 'flexible', 'Sunita Singh', '+91 9876543216', 4.8, 156, 94),
('volunteer-2', 'Ravi Kumar', 'volunteer2@demo.com', '$2b$10$example_hash', 'volunteer', '+91 9876543217', 'Lajpat Nagar, Delhi - 110024', 'bicycle', '', 'morning', 'Meera Kumar', '+91 9876543218', 4.6, 89, 91),
('volunteer-3', 'Priya Patel', 'volunteer3@demo.com', '$2b$10$example_hash', 'volunteer', '+91 9876543219', 'Dwarka, New Delhi - 110075', 'scooter', 'DL-0987654321', 'fulltime', 'Raj Patel', '+91 9876543220', 4.9, 203, 97);

-- Insert sample products
INSERT INTO products (id, supplier_id, name, description, price, category, stock_quantity, image_url) VALUES
('prod-1', 'supplier-1', 'Fresh Onions', 'Premium quality red onions, perfect for street food', 15.00, 'vegetables', 500, 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&h=400&fit=crop&crop=center'),
('prod-2', 'supplier-1', 'Tomatoes', 'Fresh ripe tomatoes, ideal for chutneys and curries', 25.00, 'vegetables', 300, 'https://images.unsplash.com/photo-1546470427-e26264be0b0d?w=400&h=400&fit=crop&crop=center'),
('prod-3', 'supplier-1', 'Green Chilies', 'Fresh green chilies for that perfect spice', 40.00, 'vegetables', 100, 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400&h=400&fit=crop&crop=center'),
('prod-4', 'supplier-1', 'Potatoes', 'Fresh potatoes perfect for aloo dishes', 12.00, 'vegetables', 400, 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&h=400&fit=crop&crop=center'),
('prod-5', 'supplier-1', 'Paneer', 'Fresh cottage cheese for delicious dishes', 200.00, 'dairy', 30, 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400&h=400&fit=crop&crop=center');

INSERT INTO products (id, supplier_id, name, description, price, category, stock_quantity, image_url) VALUES
('prod-6', 'supplier-2', 'Garam Masala', 'Authentic blend of aromatic spices', 120.00, 'spices', 50, 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=400&h=400&fit=crop&crop=center'),
('prod-7', 'supplier-2', 'Turmeric Powder', 'Pure turmeric powder for authentic flavor', 90.00, 'spices', 75, 'https://images.unsplash.com/photo-1615485500704-8e990f9900f7?w=400&h=400&fit=crop&crop=center'),
('prod-8', 'supplier-2', 'Coriander Seeds', 'Aromatic coriander seeds for tempering', 110.00, 'spices', 60, 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=400&h=400&fit=crop&crop=center');

INSERT INTO products (id, supplier_id, name, description, price, category, stock_quantity, image_url) VALUES
('prod-9', 'supplier-3', 'Basmati Rice', 'Premium long grain basmati rice', 80.00, 'grains', 200, 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&h=400&fit=crop&crop=center'),
('prod-10', 'supplier-3', 'Wheat Flour', 'Fine quality wheat flour for rotis and parathas', 35.00, 'grains', 250, 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400&h=400&fit=crop&crop=center');

-- Insert sample orders
INSERT INTO orders (id, vendor_id, volunteer_id, status, total_amount, shop_name, shop_address, shop_landmark, shop_lat, shop_lng, estimated_delivery, created_at) VALUES
('order-1', 'vendor-1', 'volunteer-1', 'delivered', 150.00, 'Raj\'s Chaat Corner', 'Shop 15, Connaught Place, New Delhi - 110001', 'Near Central Park Metro Station', 28.6315, 77.2167, DATE_ADD(NOW(), INTERVAL -22 HOUR), DATE_ADD(NOW(), INTERVAL -24 HOUR)),
('order-2', 'vendor-1', 'volunteer-1', 'in_transit', 120.00, 'Raj\'s Chaat Corner', 'Shop 15, Connaught Place, New Delhi - 110001', 'Near Central Park Metro Station', 28.6315, 77.2167, DATE_ADD(NOW(), INTERVAL 1 HOUR), DATE_ADD(NOW(), INTERVAL -2 HOUR)),
('order-3', 'vendor-2', NULL, 'pending', 200.00, 'Delhi Street Food Hub', 'Block A, Karol Bagh Market, New Delhi - 110005', 'Opposite Karol Bagh Metro Station', 28.6519, 77.1909, DATE_ADD(NOW(), INTERVAL 3 HOUR), NOW());

-- Insert sample order items
INSERT INTO order_items (id, order_id, product_id, quantity, unit_price, total_price) VALUES
('item-1', 'order-1', 'prod-1', 5, 15.00, 75.00),
('item-2', 'order-1', 'prod-2', 3, 25.00, 75.00),
('item-3', 'order-2', 'prod-6', 1, 120.00, 120.00),
('item-4', 'order-3', 'prod-9', 2, 80.00, 160.00),
('item-5', 'order-3', 'prod-3', 1, 40.00, 40.00);

-- Insert sample earnings
INSERT INTO earnings (id, volunteer_id, order_id, base_fee, distance_bonus, time_bonus, rating_bonus, total_earning, status) VALUES
('earn-1', 'volunteer-1', 'order-1', 50.00, 15.00, 25.00, 10.00, 100.00, 'paid');

-- Insert sample notifications
INSERT INTO notifications (id, user_id, title, message, type) VALUES
('notif-1', 'vendor-1', 'Order Delivered', 'Your order #1001 has been delivered successfully', 'delivery'),
('notif-2', 'supplier-1', 'New Order', 'You have received a new order from Raj\'s Chaat Corner', 'order'),
('notif-3', 'volunteer-1', 'Payment Processed', 'Your earnings of ₹100 have been processed', 'payment');
