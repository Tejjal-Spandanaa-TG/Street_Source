const mysql = require("mysql2/promise")
const fs = require("fs")
const path = require("path")

async function initializeDatabase() {
  try {
    // Create connection without database
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      port: Number.parseInt(process.env.DB_PORT || "3306"),
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
    })

    console.log("📡 Connected to MySQL server")

    // Read and execute schema
    const schemaPath = path.join(__dirname, "database-schema.sql")
    const schema = fs.readFileSync(schemaPath, "utf8")

    const statements = schema.split(";").filter((stmt) => stmt.trim())

    for (const statement of statements) {
      if (statement.trim()) {
        await connection.execute(statement)
      }
    }

    console.log("✅ Database schema created successfully")

    // Read and execute sample data
    const dataPath = path.join(__dirname, "sample-data.sql")
    const sampleData = fs.readFileSync(dataPath, "utf8")

    const dataStatements = sampleData.split(";").filter((stmt) => stmt.trim())

    for (const statement of dataStatements) {
      if (statement.trim()) {
        await connection.execute(statement)
      }
    }

    console.log("✅ Sample data inserted successfully")
    console.log("🎉 Database initialization complete!")

    await connection.end()
  } catch (error) {
    console.error("❌ Database initialization failed:", error)
    process.exit(1)
  }
}

// Run if called directly
if (require.main === module) {
  initializeDatabase()
}

module.exports = { initializeDatabase }
